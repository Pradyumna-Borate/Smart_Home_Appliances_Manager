"""Optional real hourly REFIT data (from the notebook), turned into the model's lagged format.

Used only for the 'reality check' and correlation views. The game itself does not need it to run."""
import os
import numpy as np
import pandas as pd
import config as C
import model_interface as M


def load_hourly():
    """Returns a DataFrame with the model's feature columns + the actual next-hour monitored total, or None if no data file."""
    if not os.path.exists(C.INPUT_CSV):
        return None
    X = pd.read_csv(C.INPUT_CSV, index_col="Hour", parse_dates=True).sort_index()
    energy = X[C.ENERGY_COLS]
    consecutive = pd.Series(X.index, index=X.index).diff() == pd.Timedelta(hours=1)
    lag = energy.shift(1).where(consecutive, np.nan)          # only use the previous hour if it really is the previous hour
    df = pd.DataFrame(index=X.index)
    for i in range(1, 10):
        df[f"Appliance{i}_Energy_kWh_lag1"] = lag[f"Appliance{i}_Energy_kWh"]
    df["Previous_Total_Energy_kWh"] = lag.sum(axis=1, min_count=9)
    df["Hour_sin"] = np.sin(2 * np.pi * X.index.hour / 24)
    df["Hour_cos"] = np.cos(2 * np.pi * X.index.hour / 24)
    df["Day_of_Week"] = X.index.dayofweek
    df["Month"] = X.index.month
    df[C.TARGET] = energy.sum(axis=1, min_count=9)
    df = df.dropna()
    return df[M.feature_names() + [C.TARGET]]
