@echo off
cd /d "%~dp0"
title Smart Home Manager
python --version >nul 2>&1
if errorlevel 1 (
  echo Python is not installed. Install it from python.org and tick "Add Python to PATH".
  pause
  exit /b
)
python -c "import streamlit, sklearn, pandas, joblib" >nul 2>&1
if errorlevel 1 (
  echo First run: installing requirements, please wait...
  python -m pip install -r requirements.txt
)
echo Starting the game. Your browser will open shortly. Close this window to stop.
python -m streamlit run app.py
pause
