"""Paths and the feature contract with the trained model (REFIT House 2, one-hour-ahead Random Forest)."""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "smart_home_energy_model.joblib")
METADATA_PATH = os.path.join(BASE_DIR, "smart_home_model_metadata.json")
DATA_DIR = os.path.join(BASE_DIR, "data")
# Optional: the notebook's hourly appliance file, used only for the "reality check" and correlation views
INPUT_CSV = os.path.join(DATA_DIR, "REFIT_House2_Hourly_ML_Input_Candidates.csv")
PLAYTEST_LOG = os.path.join(BASE_DIR, "playtest_log.csv")
LEARNING_LOG = os.path.join(BASE_DIR, "learning_check_log.csv")
PROGRESS_FILE = os.path.join(BASE_DIR, "progress.json")

TARGET = "Total_Energy_kWh"        # next-hour sum of the nine monitored appliances (kWh)
ENERGY_COLS = [f"Appliance{i}_Energy_kWh" for i in range(1, 10)]
