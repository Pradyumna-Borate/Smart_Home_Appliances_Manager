"""Appliance rules, tariff, comfort needs, levels and hidden-load assumptions.

PROVENANCE
- Monthly appliance averages, the hourly shape and the monitored share come from the project notebook's outputs.
- Per-use energies, allowed hours, operating modes, tariff, comfort needs and levels are GAME-DESIGN ASSUMPTIONS (ASSUMED).
- The hidden (unmonitored) load is NOT predicted by the ML model (it only covers the nine monitored appliances), so it is
  a notebook-shaped assumption: BASE_SHAPE x seasonal factor x weekend factor.
"""
import copy
import numpy as np

# id -> spec. kwh = energy for ONE use (one hour of running) in Normal mode (ASSUMED).
# modes: label -> (energy multiplier, comfort points lost). The first mode is always the default "Normal".
NORMAL = "Normal"
APPLIANCES = {
    1: dict(key="fridge",     name="Fridge-Freezer", fixed=True, kwh=0.032, peak_w=150),
    2: dict(key="washer",     name="Washing Machine", uses=1, kwh=0.70, allowed=list(range(8, 22)), peak_w=2200,
            modes={NORMAL: (1.0, 0), "Eco: 30°C wash": (0.70, 2)}, rate=0.5),
    3: dict(key="dishwasher", name="Dishwasher",      uses=1, kwh=1.00, allowed=list(range(19, 24)) + list(range(0, 7)), peak_w=2000,
            modes={NORMAL: (1.0, 0), "Eco cycle": (0.80, 2)}, rate=0.9),
    4: dict(key="tv",         name="Television",      uses=3, kwh=0.03, allowed=list(range(17, 24)), peak_w=120,
            modes={NORMAL: (1.0, 0)}, rate=2.5),
    5: dict(key="microwave",  name="Microwave",       uses=2, kwh=0.05, allowed=list(range(7, 22)), peak_w=1200,
            modes={NORMAL: (1.0, 0)}, rate=1.5),
    6: dict(key="toaster",    name="Toaster",         uses=1, kwh=0.03, allowed=list(range(6, 10)), peak_w=1000,
            modes={NORMAL: (1.0, 0)}, rate=0.6),
    7: dict(key="hifi",       name="Hi-Fi",           uses=2, kwh=0.02, allowed=list(range(9, 24)), peak_w=60,
            modes={NORMAL: (1.0, 0)}, rate=1.2),
    8: dict(key="kettle",     name="Kettle",          uses=4, kwh=0.12, allowed=list(range(6, 24)), peak_w=2200,
            modes={NORMAL: (1.0, 0), "Boil only what you need": (0.70, 2)}, rate=4.0),
    9: dict(key="extractor",  name="Oven Extractor",  linked="microwave", ratio=0.2, peak_w=60),
}
KEY2ID = {s["key"]: i for i, s in APPLIANCES.items()}
FRIDGE_KWH = APPLIANCES[1]["kwh"]
CONTROLLABLE = ["dishwasher", "washer", "kettle", "microwave", "toaster", "tv", "hifi"]
COMFORT_WEIGHT = {"dishwasher": 3, "washer": 2, "kettle": 3, "microwave": 1, "toaster": 1, "tv": 1, "hifi": 0.5}


def mode_labels(key):
    return list(APPLIANCES[KEY2ID[key]]["modes"])


def mode_mult(key, mode):
    return APPLIANCES[KEY2ID[key]]["modes"][mode][0]


def mode_comfort_cost(key, mode):
    return APPLIANCES[KEY2ID[key]]["modes"][mode][1]


def lowest_energy_mode(key):
    m = APPLIANCES[KEY2ID[key]]["modes"]
    return min(m, key=lambda x: m[x][0])


# What a wasteful household does: everything in the evening peak (ASSUMED)
PREFERRED = {
    "washer": [17, 18, 16, 15], "dishwasher": [19, 20, 21, 22], "kettle": [7, 8, 17, 18, 19, 16, 12],
    "tv": [18, 19, 20, 21, 22], "microwave": [18, 19, 12, 13], "toaster": [8, 7], "hifi": [18, 19, 20, 21],
}

# ---------- tariffs (GBP per kWh, ASSUMED / illustrative) ----------
TARIFFS = {
    "tou":   dict(name="Time-of-use",      values=[0.10] * 7 + [0.20] * 9 + [0.35] * 4 + [0.20] * 4,
                  note="Cheap overnight, expensive in the 16:00-19:59 evening peak."),
    "flat":  dict(name="Flat rate",        values=[0.22] * 24,
                  note="Every hour costs the same, so only HOW MUCH energy you use matters."),
    "solar": dict(name="Solar-surplus",    values=[0.12] * 7 + [0.20] * 3 + [0.08] * 6 + [0.32] * 6 + [0.15] * 2,
                  note="Rooftop solar floods the grid at midday (cheapest), then a steep evening price."),
    "surge": dict(name="Surge pricing",    values=[0.08] * 6 + [0.22] * 11 + [0.60] * 4 + [0.22] * 3,
                  note="Very cheap at night, but a brutal 17:00-20:59 surge price."),
}
for _t in TARIFFS.values():
    _t["array"] = np.array(_t["values"], dtype=float)
    assert len(_t["array"]) == 24
TARIFF = TARIFFS["tou"]["array"]                 # default tariff (kept for backwards compatibility)


def tariff_for(level=None):
    return TARIFFS[(level or {}).get("tariff", "tou")]["array"]


def band(h, tariff=None):
    """Colour band of hour h relative to the cheapest and dearest hour of the tariff (all yellow when flat)."""
    t = TARIFF if tariff is None else tariff
    lo, hi = float(t.min()), float(t.max())
    if hi - lo < 1e-9:
        return "🟡"
    pos = (float(t[h]) - lo) / (hi - lo)
    return "🟢" if pos <= 0.25 else "🔴" if pos >= 0.75 else "🟡"


def tariff_runs(tariff):
    """[(start_hour, end_hour, price)] for contiguous hours with the same price."""
    runs = []
    for h, p in enumerate(tariff):
        if runs and abs(runs[-1][2] - p) < 1e-9:
            runs[-1][1] = h
        else:
            runs.append([h, h, float(p)])
    return runs


def tariff_caption(tariff):
    return " · ".join(f"{band(a, tariff)} {a:02d}–{b:02d} £{p:.2f}" for a, b, p in tariff_runs(tariff)) + " per kWh (illustrative)"


def hour_ranges(hours):
    """'23:00-06:59, 12:00-12:59' style text for a list of hours (merges a run that wraps past midnight)."""
    runs = []
    for h in sorted(set(hours)):
        if runs and h == runs[-1][1] + 1:
            runs[-1][1] = h
        else:
            runs.append([h, h])
    if len(runs) > 1 and runs[0][0] == 0 and runs[-1][1] == 23:
        runs[0][0] = runs[-1][0]
        runs.pop()
    return ", ".join(f"{a:02d}:00–{b:02d}:59" for a, b in runs)


# Comfort needs: things the household genuinely needs done (ASSUMED). Missing one costs comfort points.
NEEDS = {
    "breakfast":   dict(label="Hot breakfast: kettle or toaster used between 06:00 and 09:59",
                        appliances=["kettle", "toaster"], hours=list(range(6, 10)), penalty=15),
    "laundry":     dict(label="School uniforms: washing machine run between 08:00 and 15:59",
                        appliances=["washer"], hours=list(range(8, 16)), penalty=15),
    "dinner":      dict(label="Hot dinner: microwave used between 17:00 and 20:59",
                        appliances=["microwave"], hours=list(range(17, 21)), penalty=10),
    "evening_tv":  dict(label="Family TV time: television on between 18:00 and 21:59",
                        appliances=["tv"], hours=list(range(18, 22)), penalty=10),
    "tea_time":    dict(label="Visitors' tea: kettle used between 15:00 and 17:59",
                        appliances=["kettle"], hours=list(range(15, 18)), penalty=10),
    "guest_music": dict(label="Music for the guests: Hi-Fi on between 19:00 and 22:59",
                        appliances=["hifi"], hours=list(range(19, 23)), penalty=8),
    "brunch":      dict(label="Weekend brunch: kettle or microwave used between 10:00 and 11:59",
                        appliances=["kettle", "microwave"], hours=list(range(10, 12)), penalty=10),
}

# Average whole-house energy by hour of day (kWh/h), read from the notebook's hourly chart (approximate)
HOURLY_TOTAL = np.array([.42, .36, .32, .29, .29, .28, .35, .82, 2.2, 1.18, .61, .53,
                         .64, .69, .73, .67, 1.01, 1.22, 1.07, .98, 1.08, .94, .69, .54]) * 0.45
# Unmonitored ("hidden") base-load shape per hour (ASSUMED from the notebook chart)
BASE_SHAPE = np.maximum((HOURLY_TOTAL - 0.10) * 1.2, 0.08)
# Seasonal multiplier from the notebook's monthly unmonitored energy (Jan high, Aug low; Nov/Dec approximated)
MONTH_FACTOR = {1: 1.6, 2: 1.5, 3: 1.2, 4: 1.07, 5: 1.0, 6: 0.93, 7: 0.75, 8: 0.58, 9: 0.88, 10: 0.93, 11: 1.1, 12: 1.45}
WEEKEND_FACTOR = 1.15


def hidden_load(month, weekday, level=None):
    """24 hourly kWh of unmonitored load (heating, lighting, other devices). Not predicted by the ML model.
    A level may scale it (extreme weather: hidden_mult) or add to it (guests: hidden_extra {hour: kWh})."""
    h = BASE_SHAPE * MONTH_FACTOR[month] * (WEEKEND_FACTOR if weekday >= 5 else 1.0)
    if level:
        h = h * level.get("hidden_mult", 1.0)
        for hr, kwh in level.get("hidden_extra", {}).items():
            h[int(hr)] += kwh
    return h


# Notebook EDA facts (13 retained months), used by the Insights page
MONTHLY_AVG_KWH = {"Dishwasher": 37.1, "Fridge-Freezer": 23.2, "Kettle": 14.2, "Washing Machine": 11.3,
                   "Television": 2.5, "Microwave": 2.0, "Hi-Fi": 1.2, "Toaster": 0.8, "Oven Extractor": 0.2}
MONITORED_SHARE = 0.34

# Recurring "quiet hour" blocks (neighbours / sleeping guests) and the reason Eco is sometimes unavailable
QUIET_NIGHT = [23] + list(range(0, 7))
QUIET_WASH = [8, 9, 20, 21]

TIERS = {1: "Beginner", 2: "Intermediate", 3: "Advanced", 4: "Expert"}

# difficulty = how much of the possible savings you must achieve (0.5 = half of the way from wasteful to the cheapest plan).
# Optional twists per level: tariff, blocked {appliance: hours}, locked_modes [appliances with no Eco mode],
# hidden_mult (x hidden load), hidden_extra {hour: extra hidden kWh}, event (text shown to the player).
_LEVELS = [
    dict(id="mild_weekday", title="Mild Weekday", tier=1, month=5, weekday=2, uses={}, difficulty=0.50, peak_limit=2.5,
         comfort_min=80, needs=["breakfast", "laundry"],
         tip="Warm-up. Green hours are cheap, red hours are expensive. Try the Eco modes."),
    dict(id="winter_weekday", title="Winter Weekday", tier=1, month=1, weekday=1, uses={}, difficulty=0.60, peak_limit=2.3,
         comfort_min=80, needs=["breakfast", "laundry"],
         tip="Winter: the house already uses lots of energy you cannot see or control."),
    dict(id="flat_rate_friday", title="Flat-Rate Friday", tier=1, month=4, weekday=4, uses={}, difficulty=0.55, peak_limit=2.4,
         comfort_min=80, needs=["breakfast", "laundry"], tariff="flat",
         tip="Every hour costs the same today. Timing barely changes the bill, so the Eco modes are your main weapon."),
    dict(id="laundry_weekend", title="Laundry Weekend", tier=2, month=3, weekday=5,
         uses={"washer": 2, "dishwasher": 2, "kettle": 6, "tv": 5, "microwave": 3},
         difficulty=0.60, peak_limit=2.1, comfort_min=80, needs=["breakfast"],
         tip="Busy day. The model expects a big appliance to keep drawing power in the next hour."),
    dict(id="solar_saturday", title="Solar Saturday", tier=2, month=6, weekday=5,
         uses={"washer": 2, "dishwasher": 1, "kettle": 5, "tv": 4, "microwave": 3},
         difficulty=0.62, peak_limit=1.55, comfort_min=80, needs=["brunch", "laundry"], tariff="solar",
         tip="The cheapest power of the day is at midday, not at night. Chase the green hours."),
    dict(id="quiet_neighbours", title="Quiet Neighbours", tier=2, month=10, weekday=3, uses={},
         difficulty=0.65, peak_limit=1.6, comfort_min=80, needs=["breakfast", "laundry", "dinner"],
         blocked={"dishwasher": QUIET_NIGHT, "washer": QUIET_WASH},
         event="Thin walls: the dishwasher cannot run overnight and the washer is banned early morning and late evening.",
         tip="Your cheapest hours are blocked. Find the next-cheapest slots."),
    dict(id="winter_party", title="Winter Party", tier=3, month=1, weekday=5,
         uses={"washer": 2, "dishwasher": 2, "kettle": 6, "tv": 5, "microwave": 3, "toaster": 2},
         difficulty=0.75, peak_limit=2.2, comfort_min=80, needs=["breakfast"],
         tip="High hidden load, many chores, tight peak limit."),
    dict(id="surge_thursday", title="Surge Thursday", tier=3, month=2, weekday=3, uses={},
         difficulty=0.70, peak_limit=1.85, comfort_min=80, needs=["breakfast", "dinner", "evening_tv"], tariff="surge",
         tip="Dinner and TV time both fall in the surge window. Can you keep them cheap with small, short uses?"),
    dict(id="heavy_laundry", title="Heavy Laundry Week", tier=3, month=11, weekday=0,
         uses={"washer": 3, "dishwasher": 2, "kettle": 5},
         difficulty=0.70, peak_limit=2.15, comfort_min=82, needs=["breakfast", "laundry"], locked_modes=["washer"],
         event="Muddy sports kit: the washing machine needs a full Normal wash, so Eco is unavailable for it.",
         tip="One of your best savings tools is locked. Work the timing and the other Eco modes harder."),
    dict(id="dinner_guests", title="Dinner Guests", tier=4, month=12, weekday=5,
         uses={"washer": 2, "dishwasher": 2, "kettle": 6, "tv": 5, "microwave": 4, "toaster": 2, "hifi": 4},
         difficulty=0.78, peak_limit=2.1, comfort_min=82, needs=["brunch", "tea_time", "dinner", "guest_music"],
         tariff="surge", blocked={"dishwasher": [19, 20, 21]}, hidden_extra={h: 0.25 for h in range(17, 22)},
         event="Guests are over: cooking and lighting add hidden load from 17:00 to 21:59, and the dishwasher cannot run during dinner.",
         tip="Many chores, hidden extra load and a surge tariff. Everything must be spread out."),
    dict(id="cold_snap", title="Cold-Snap Watch", tier=4, month=1, weekday=1,
         uses={"kettle": 5, "microwave": 3}, difficulty=0.80, peak_limit=2.45, comfort_min=82,
         needs=["breakfast", "laundry", "dinner"], tariff="surge", locked_modes=["dishwasher"], hidden_mult=1.25,
         event="Freezing snap: heating pushes the hidden load up 25%, so the supply limit bites harder. The dishwasher needs its full cycle.",
         tip="Hidden load is huge. Keep each hour under the limit while dodging the surge."),
    dict(id="grand_finale", title="Grand Finale", tier=4, month=1, weekday=6,
         uses={"washer": 2, "dishwasher": 2, "kettle": 6, "tv": 5, "microwave": 4, "toaster": 2, "hifi": 3},
         difficulty=0.82, peak_limit=2.55, comfort_min=85, needs=["brunch", "dinner", "evening_tv"],
         tariff="surge", blocked={"dishwasher": QUIET_NIGHT, "washer": [8, 9]}, locked_modes=["washer"],
         hidden_mult=1.15, hidden_extra={h: 0.2 for h in range(17, 22)},
         event="Everything at once: winter Sunday, surge prices, guests, quiet hours and a muddy-kit wash.",
         tip="The final exam. Use everything you have learned about timing, modes and the model's knock-on."),
]
LEVELS = []
for _i, _lv in enumerate(_LEVELS):
    _lv = dict(_lv)
    _lv["name"] = f"Level {_i + 1} · {_lv['title']}"
    LEVELS.append(_lv)
LEVEL_BY_ID = {lv["id"]: lv for lv in LEVELS}
assert len(LEVEL_BY_ID) == len(LEVELS), "level ids must be unique"
LEGACY_LEVEL_IDS = {0: "mild_weekday", 1: "winter_weekday", 2: "laundry_weekend", 3: "winter_party"}   # old progress.json keys

# ---------- difficulty settings: tune any level without editing it ----------
DIFFICULTIES = {
    "Relaxed":   dict(budget=-0.15, peak=+0.25, comfort=-5, score_mult=0.8, star_cap=2,
                      desc="Looser budget, higher supply limit, lower comfort bar. Scores x0.8 and up to 2 stars."),
    "Standard":  dict(budget=0.0, peak=0.0, comfort=0, score_mult=1.0, star_cap=3,
                      desc="The level as designed."),
    "Challenge": dict(budget=+0.10, peak=-0.10, comfort=+4, score_mult=1.25, star_cap=3,
                      desc="Tighter budget, lower supply limit, higher comfort bar. Scores x1.25."),
}


def apply_difficulty(level, mode="Standard"):
    """Copy of a level with the chosen difficulty applied (the original is not changed)."""
    d = DIFFICULTIES[mode]
    lv = copy.deepcopy(level)
    lv["difficulty"] = round(min(0.88, max(0.2, level["difficulty"] + d["budget"])), 3)
    lv["peak_limit"] = round(level["peak_limit"] + d["peak"], 3)
    lv["comfort_min"] = level["comfort_min"] + d["comfort"]
    lv["score_mult"], lv["star_cap"], lv["mode_name"] = d["score_mult"], d["star_cap"], mode
    return lv


def describe_rules(level):
    """Plain-language list of the day's special rules, for the briefing panel."""
    nm = {s["key"]: s["name"] for s in APPLIANCES.values()}
    t = TARIFFS[level.get("tariff", "tou")]
    rules = [f"Tariff: **{t['name']}**. {t['note']}"]
    for k, hrs in level.get("blocked", {}).items():
        rules.append(f"🔇 {nm[k]} **cannot run** {hour_ranges(hrs)}.")
    for k in level.get("locked_modes", []):
        rules.append(f"🔒 {nm[k]}: **no Eco mode** today.")
    if level.get("hidden_mult", 1.0) != 1.0:
        rules.append(f"🥶 Hidden load is x{level['hidden_mult']:.2f} (extreme weather).")
    if level.get("hidden_extra"):
        hrs = sorted(level["hidden_extra"])
        rules.append(f"👥 Extra hidden load of about {max(level['hidden_extra'].values()):.2f} kWh/h during {hour_ranges(hrs)}.")
    return rules


def random_level(seed, tier=2):
    """A reproducible random day. Its supply limit is set by the engine afterwards so that it is always solvable."""
    rng = np.random.default_rng(int(seed))
    weekday = int(rng.integers(0, 7))
    month = int(rng.integers(1, 13))
    heavy = weekday >= 5 or tier >= 3
    uses = {}
    if heavy:
        uses = {"washer": int(rng.integers(1, 3)), "dishwasher": int(rng.integers(1, 3)), "kettle": int(rng.integers(4, 7)),
                "tv": int(rng.integers(3, 6)), "microwave": int(rng.integers(2, 4))}
    lv = dict(id=f"random_{int(seed)}", title=f"Random Day #{int(seed)}", name=f"🎲 Random Day #{int(seed)}", tier=tier,
              month=month, weekday=weekday, uses=uses, difficulty=round(0.5 + 0.08 * tier, 3), peak_limit=99.0,
              comfort_min=80, needs=["breakfast"], random=True)
    lv["tariff"] = str(rng.choice(list(TARIFFS)))
    if rng.random() < 0.7:
        lv["needs"].append("laundry")
    extra_needs = ["dinner", "evening_tv", "tea_time", "guest_music"]
    for n in rng.choice(extra_needs, size=min(tier - 1, 3), replace=False) if tier > 1 else []:
        lv["needs"].append(str(n))
    twists = []
    if tier >= 2 and rng.random() < 0.5:
        lv["blocked"] = {"dishwasher": QUIET_NIGHT} if rng.random() < 0.5 else {"washer": QUIET_WASH}
        twists.append("quiet hours")
    if tier >= 3 and rng.random() < 0.6:
        lv["locked_modes"] = [str(rng.choice(["washer", "dishwasher", "kettle"]))]
        twists.append("a locked Eco mode")
    if tier >= 2 and rng.random() < 0.5:
        lv["hidden_extra"] = {h: round(float(0.1 * tier), 2) for h in range(17, 22)}
        twists.append("evening guests")
    if tier >= 3 and rng.random() < 0.4:
        lv["hidden_mult"] = 1.2
        twists.append("extreme weather")
    lv["event"] = ("Today's twists: " + ", ".join(twists) + ".") if twists else "No special twists today, just the tariff and the weather."
    lv["tip"] = "A freshly generated day. The same seed always gives the same day."
    return lv


