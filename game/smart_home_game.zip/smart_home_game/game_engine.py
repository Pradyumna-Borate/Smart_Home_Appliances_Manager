"""Game rules (no Streamlit). A schedule is {appliance_key: {"hours": [..], "mode": "Normal" | "Eco ..."}}.

HOW THE ML MODEL IS USED
The trained model forecasts the NEXT hour's monitored energy from the PREVIOUS hour's appliance readings. So for every hour h
the game feeds it the appliance energies the player scheduled for hour h-1 (hour 23 wraps to hour 0: the day repeats).
Energy in hour h =
    direct    what the player's scheduled appliances use in hour h (per-use energies, ASSUMED in profiles.py)
  + knock-on  what the MODEL expects to continue/follow from the previous hour's appliance use
              = model(previous-hour state) - model(previous hour with only the fridge on)
  + hidden    unmonitored load (heating, lighting...), a notebook-shaped assumption, NOT from the model
The knock-on term is learned from real data (e.g. a dishwasher run is usually followed by more use in the next hour),
so the player's decisions (hours, modes, number of uses) change the model's inputs and therefore its predictions.
"""
import functools
import json
import numpy as np
import config as C
import profiles as P
import model_interface as M

HOURS = list(range(24))
def next_tariff(tariff):
    """Tariff of hour h+1 (a knock-on of hour h is paid in hour h+1)."""
    return np.roll(tariff, -1)


NEXT_TARIFF = next_tariff(P.TARIFF)              # default tariff, kept for backwards compatibility


def uses_for(level):
    return {k: level["uses"].get(k, P.APPLIANCES[P.KEY2ID[k]]["uses"]) for k in P.CONTROLLABLE}


# ---------- level rules ----------
def allowed_hours(level, key):
    """Hours an appliance may run in this level (its normal window minus any blocked 'quiet hours')."""
    blocked = set(level.get("blocked", {}).get(key, []))
    return [h for h in P.APPLIANCES[P.KEY2ID[key]]["allowed"] if h not in blocked]


def mode_options(level, key):
    """Operating modes the player may pick: Eco modes disappear on levels that lock them."""
    labels = P.mode_labels(key)
    return [P.NORMAL] if key in level.get("locked_modes", []) else labels


def best_mode(level, key):
    opts = mode_options(level, key)
    return P.lowest_energy_mode(key) if len(opts) > 1 else P.NORMAL


def _level_key(level):
    return json.dumps(level, sort_keys=True, default=str)


# ---------- schedules ----------
def baseline_schedule(level):
    uses = uses_for(level)
    sched = {}
    for k in P.CONTROLLABLE:
        allowed = allowed_hours(level, k)
        pref = [h for h in P.PREFERRED[k] if h in allowed]
        rest = [h for h in allowed if h not in pref]
        sched[k] = {"hours": (pref + rest)[:uses[k]], "mode": P.NORMAL}
    return sched


def need_met(schedule, need_id):
    n = P.NEEDS[need_id]
    return any(h in n["hours"] for k in n["appliances"] for h in schedule[k]["hours"])


_SMART_CACHE = {}


def smart_schedule(level):
    """Cheap, feasible plan used to make budgets solvable: respects blocked hours, locked modes, needs and the supply limit.
    Greedy placement using the model's own knock-on estimate, then a repair loop that moves uses out of overloaded hours."""
    key = _level_key(level)
    if key not in _SMART_CACHE:
        _SMART_CACHE[key] = _build_smart(level)
    return {k: {"hours": list(v["hours"]), "mode": v["mode"]} for k, v in _SMART_CACHE[key].items()}


def _build_smart(level):
    uses = uses_for(level)
    tariff = P.tariff_for(level)
    nxt = next_tariff(tariff)
    month, wd, limit = level["month"], level["weekday"], level["peak_limit"] - 0.05
    modes = {k: best_mode(level, k) for k in P.CONTROLLABLE}
    est = {}
    for k in P.CONTROLLABLE:
        r = marginal_by_hour(k, modes[k], month, wd, tariff)
        est[k] = (float(r["direct"][0]), r["carry"])
    load = P.hidden_load(month, wd, level) + P.FRIDGE_KWH
    sched = {k: {"hours": [], "mode": modes[k]} for k in P.CONTROLLABLE}

    def rank(k, h):
        e, c = est[k]
        over = max(0.0, load[h] + e - limit) + max(0.0, load[(h + 1) % 24] + c[h] - limit)
        return (round(over, 3), round(e * tariff[h] + c[h] * nxt[h], 4), load[h])

    def place(k, h):
        sched[k]["hours"].append(h)
        e, c = est[k]
        load[h] += e
        load[(h + 1) % 24] += c[h]

    def free_hours(k):
        return [h for h in allowed_hours(level, k) if h not in sched[k]["hours"]]

    # 1. household needs first (fewest options first), cheapest feasible appliance/hour for each
    def options(nid):
        n = P.NEEDS[nid]
        return [(k, h) for k in n["appliances"] for h in n["hours"] if h in free_hours(k)]

    for nid in sorted(level["needs"], key=lambda n: len(options(n))):
        if need_met(sched, nid):
            continue
        cands = [(k, h) for k, h in options(nid) if len(sched[k]["hours"]) < uses[k]]
        if not cands:
            raise ValueError(f"Level '{level.get('name')}' has an impossible need: {nid}")
        k, h = min(cands, key=lambda kh: rank(*kh))
        place(k, h)
    # 2. everything else, biggest appliances first
    for k in sorted(P.CONTROLLABLE, key=lambda x: -est[x][0]):
        while len(sched[k]["hours"]) < uses[k]:
            fh = free_hours(k)
            if not fh:
                raise ValueError(f"Level '{level.get('name')}' has no free hour left for {k}")
            place(k, min(fh, key=lambda h: rank(k, h)))
    # 3. repair: the real model may still push an hour over the limit
    for _ in range(40):
        res = evaluate(sched, level)
        if not res["overload_hours"]:
            break
        best = None
        for o in res["overload_hours"]:
            for k in P.CONTROLLABLE:
                if o not in sched[k]["hours"]:
                    continue
                for h2 in free_hours(k):
                    trial = {kk: {"hours": list(v["hours"]), "mode": v["mode"]} for kk, v in sched.items()}
                    trial[k]["hours"] = sorted([x for x in trial[k]["hours"] if x != o] + [h2])
                    if not all(need_met(trial, n) for n in level["needs"]):
                        continue
                    r2 = evaluate(trial, level)
                    score = (len(r2["overload_hours"]), r2["cost"])
                    if best is None or score < best[0]:
                        best = (score, trial)
        if best is None or best[0][0] >= len(res["overload_hours"]):
            break
        sched = best[1]
    for k in sched:
        sched[k]["hours"] = sorted(sched[k]["hours"])
    return sched


# ---------- energy matrix and model prediction ----------
def appliance_matrix(schedule):
    """9 x 24 kWh matrix of appliance energy actually used (rows = appliance ids 1..9)."""
    m = np.zeros((9, 24))
    m[0, :] = P.FRIDGE_KWH                                           # fridge always on
    for k, s in schedule.items():
        spec = P.APPLIANCES[P.KEY2ID[k]]
        e = spec["kwh"] * P.mode_mult(k, s["mode"])
        for h in set(s["hours"]):
            m[P.KEY2ID[k] - 1, h] = e
    m[8, :] = P.APPLIANCES[9]["ratio"] * m[4, :]                     # extractor runs with the microwave
    return m


@functools.lru_cache(maxsize=None)
def _idle_forecast(weekday, month):
    """Model forecast per hour when only the fridge ran in the previous hour (the 'nothing happened' reference)."""
    feats = [M.build_features({1: P.FRIDGE_KWH}, h, weekday, month) for h in HOURS]
    return tuple(M.predict_many(feats))


def knock_on(matrix, weekday, month):
    """24 hourly kWh the model expects to follow from the previous hour's appliance use (never negative)."""
    prev = np.roll(matrix, 1, axis=1)                                # column h = appliance state in hour h-1 (wraps)
    feats = [M.build_features({i + 1: prev[i, h] for i in range(9)}, h, weekday, month) for h in HOURS]
    return np.clip(M.predict_many(feats) - np.array(_idle_forecast(weekday, month)), 0, None)


def energy_profile(matrix, month, weekday, level=None):
    direct = matrix.sum(0)
    carry = knock_on(matrix, weekday, month)
    hidden = P.hidden_load(month, weekday, level)
    return direct, carry, hidden


def comfort_score(schedule, level):
    uses = uses_for(level)
    num = den = 0.0
    for k in P.CONTROLLABLE:
        w = P.COMFORT_WEIGHT[k]
        num += w * min(1.0, len(set(schedule[k]["hours"])) / uses[k]); den += w
    score = 100 * num / den
    score -= sum(P.mode_comfort_cost(k, schedule[k]["mode"]) for k in P.CONTROLLABLE if schedule[k]["hours"])
    score -= sum(P.NEEDS[n]["penalty"] for n in level["needs"] if not need_met(schedule, n))
    return max(0.0, score)


def evaluate(schedule, level):
    mat = appliance_matrix(schedule)
    direct, carry, hidden = energy_profile(mat, level["month"], level["weekday"], level)
    tariff = P.tariff_for(level)
    pred = direct + carry + hidden                                   # household kWh per hour
    cost = float((pred * tariff).sum())
    unc = float(np.sqrt(((M.rmse() * tariff) ** 2).sum()))         # cautious: model test RMSE applied to every hour, independent
    monitored = direct + carry
    return {"pred": pred, "direct": direct, "carry": carry, "hidden": hidden, "matrix": mat,
            "kwh": float(pred.sum()), "cost": cost, "cost_unc": unc,
            "overload_hours": [h for h in HOURS if pred[h] > level["peak_limit"]],
            "comfort": comfort_score(schedule, level),
            "needs": {n: need_met(schedule, n) for n in level["needs"]},
            "monitored_share": float(monitored.sum() / max(pred.sum(), 1e-9)),
            "hidden_kwh": float(hidden.sum()), "carry_kwh": float(carry.sum())}


_BUDGET_CACHE = {}


def make_budget(level):
    key = _level_key(level)
    if key not in _BUDGET_CACHE:
        base = evaluate(baseline_schedule(level), level)
        smart = evaluate(smart_schedule(level), level)
        _BUDGET_CACHE[key] = (base, smart, base["cost"] - level["difficulty"] * (base["cost"] - smart["cost"]))
    return _BUDGET_CACHE[key]


def score_day(res, base, smart, budget, level):
    passed = (res["cost"] <= budget and res["comfort"] >= level["comfort_min"] and not res["overload_hours"])
    span = max(base["cost"] - smart["cost"], 1e-9)
    saved_ratio = (base["cost"] - res["cost"]) / span
    score = (700 * max(0, min(saved_ratio, 1.2)) + 3 * res["comfort"] - 100 * len(res["overload_hours"])) * level.get("score_mult", 1.0)
    stars = 0
    if passed:
        stars = 1 + (res["comfort"] >= 90) + (res["comfort"] >= 90 and saved_ratio >= 0.9)
        stars = min(stars, level.get("star_cap", 3))
    return passed, max(0, int(round(score))), int(stars), saved_ratio


# ---------- learning feedback ----------
def attribution(schedule, level):
    """GBP saved by each appliance decision = revert only that appliance to the wasteful default and re-run the model."""
    base = baseline_schedule(level)
    cur = evaluate(schedule, level)
    out = {}
    for k in P.CONTROLLABLE:
        alt = dict(schedule); alt[k] = base[k]
        a = evaluate(alt, level)
        out[k] = {"cost": a["cost"] - cur["cost"], "kwh": a["kwh"] - cur["kwh"]}
    return out


def marginal_by_hour(key, mode, month, weekday, tariff=None):
    """Extra household energy/cost caused by ONE use of an appliance started in each hour (everything else idle).
    Split into the appliance's own energy and the model's expected knock-on in the following hour."""
    spec = P.APPLIANCES[P.KEY2ID[key]]
    e = spec["kwh"] * P.mode_mult(key, mode)
    state = {1: P.FRIDGE_KWH, P.KEY2ID[key]: e}
    direct_e = e
    if key == "microwave":
        state[9] = P.APPLIANCES[9]["ratio"] * e
        direct_e += state[9]
    with_f = [M.build_features(state, (h + 1) % 24, weekday, month) for h in HOURS]
    idle_f = [M.build_features({1: P.FRIDGE_KWH}, (h + 1) % 24, weekday, month) for h in HOURS]
    carry = np.clip(M.predict_many(with_f) - M.predict_many(idle_f), 0, None)
    direct = np.full(24, direct_e)
    t = P.TARIFF if tariff is None else tariff
    return {"direct": direct, "carry": carry, "kwh": direct + carry, "cost": direct * t + carry * next_tariff(t)}


def reality_check(df, n=12, seed=0):
    """Model forecast vs measured monitored energy on random real hours (needs the optional real data file).
    Some of these hours may have been in the model's training data: the official test scores are in the metadata."""
    rng = np.random.default_rng(seed)
    rows = df.iloc[rng.choice(len(df), size=min(n, len(df)), replace=False)].sort_index()
    pred = M.predict_many([r[M.feature_names()].to_dict() for _, r in rows.iterrows()])
    return [{"hour": str(i), "predicted_kWh": round(float(p), 3), "actual_kWh": round(float(a), 3)}
            for i, p, a in zip(rows.index, pred, rows[C.TARGET])]


# ---------- solvability and random days ----------
def check_solvable(level):
    """True if the cheap plan passes every rule of this level: budget, comfort, needs and the supply limit."""
    base, smart, budget = make_budget(level)
    return bool(smart["cost"] < budget < base["cost"] and not smart["overload_hours"]
                and smart["comfort"] >= level["comfort_min"] and all(smart["needs"].values()))


def build_random_level(seed, tier=2):
    """Random day whose supply limit is set from the cheapest plan (with slack that shrinks with the tier), so it is solvable."""
    slack = {1: 0.50, 2: 0.40, 3: 0.30, 4: 0.25}[tier]
    for attempt in range(25):
        lv = P.random_level(seed + attempt * 7919, tier)
        try:
            free = dict(lv, peak_limit=99.0)
            smart = evaluate(smart_schedule(free), free)
            lv["peak_limit"] = round(float(smart["pred"].max()) + slack, 2)
            if check_solvable(lv):
                lv.update(id=f"random_{int(seed)}", title=f"Random Day #{int(seed)}", name=f"🎲 Random Day #{int(seed)}")
                return lv
        except ValueError:
            continue
    raise RuntimeError("Could not build a solvable random day")
