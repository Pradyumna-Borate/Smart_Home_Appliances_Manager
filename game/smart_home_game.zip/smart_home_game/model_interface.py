"""The ONLY file that touches the trained model.

smart_home_energy_model.joblib is a dict:
  model            sklearn Pipeline (median imputer + tuned RandomForestRegressor)
  feature_columns  the 14 inputs, in order (previous-hour appliance energies, previous total, hour sin/cos, weekday, month)
  target_name / target_unit / model_name / prediction_horizon
smart_home_model_metadata.json holds the held-out test metrics, baselines and the model's documented limitations.

The model forecasts the NEXT hour's total energy of the nine monitored appliances from the PREVIOUS hour's readings.
"""
import json
import os
import joblib
import numpy as np
import pandas as pd
import config as C

_BUNDLE = None
FALLBACK_RMSE = 0.1835           # used only if the metadata file is missing


def get_bundle():
    global _BUNDLE
    if _BUNDLE is None:
        if not os.path.exists(C.MODEL_PATH):
            raise FileNotFoundError(f"Trained model not found: {C.MODEL_PATH}")
        raw = joblib.load(C.MODEL_PATH)
        meta = {}
        if os.path.exists(C.METADATA_PATH):
            with open(C.METADATA_PATH, encoding="utf-8") as f:
                meta = json.load(f)
        _BUNDLE = {"model": raw["model"], "features": list(raw["feature_columns"]),
                   "name": raw.get("model_name", "model"), "meta": meta}
    return _BUNDLE


def feature_names():
    return get_bundle()["features"]


def build_features(prev_app_kwh, hour, weekday, month):
    """prev_app_kwh: {appliance_id 1..9: kWh used in the PREVIOUS hour}; hour/weekday/month describe the hour being forecast.
    ASSUMPTION: Hour_sin/Hour_cos were computed from the hour being predicted (the row's timestamp) when training.
    weekday: 0 = Monday .. 6 = Sunday."""
    f = {f"Appliance{i}_Energy_kWh_lag1": float(prev_app_kwh.get(i, 0.0)) for i in range(1, 10)}
    f["Previous_Total_Energy_kWh"] = sum(f[f"Appliance{i}_Energy_kWh_lag1"] for i in range(1, 10))
    f["Hour_sin"] = float(np.sin(2 * np.pi * hour / 24))
    f["Hour_cos"] = float(np.cos(2 * np.pi * hour / 24))
    f["Day_of_Week"] = int(weekday)
    f["Month"] = int(month)
    return f


def predict_many(feature_dicts):
    b = get_bundle()
    X = pd.DataFrame(feature_dicts)
    missing = [c for c in b["features"] if c not in X.columns]
    if missing:
        raise KeyError(f"Game cannot supply features the model needs: {missing}")
    return np.clip(b["model"].predict(X[b["features"]]), 0, None)


def model_name():
    return get_bundle()["name"]


def metrics():
    """Held-out test metrics for the model and both baselines (from the metadata file)."""
    return get_bundle()["meta"].get("test_performance", {})


def rmse():
    return float(metrics().get(model_name(), {}).get("RMSE", FALLBACK_RMSE))


def mae():
    return float(metrics().get(model_name(), {}).get("MAE", float("nan")))


def limitations():
    return get_bundle()["meta"].get("limitations", [])


def importances():
    est = get_bundle()["model"]
    est = est.steps[-1][1] if hasattr(est, "steps") else est
    imp = getattr(est, "feature_importances_", None)
    return dict(zip(feature_names(), map(float, imp))) if imp is not None else {}
