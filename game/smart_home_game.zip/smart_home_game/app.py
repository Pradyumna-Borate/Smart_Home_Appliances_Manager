"""Smart Home Appliances Manager - run with:  streamlit run app.py"""
import csv, os, time
import numpy as np
import pandas as pd
import streamlit as st
import config as C
import profiles as P
import data_loader as D
import model_interface as M
import game_engine as G
import progress as PR

st.set_page_config(page_title="Smart Home Appliances Manager", page_icon="🏠", layout="wide")


@st.cache_data
def get_data():
    return D.load_hourly()


df = get_data()
ss = st.session_state
ss.setdefault("game", None)
ss.setdefault("passed", set())
ss.setdefault("run_id", 0)
ss.setdefault("player", "")
ss.setdefault("pre_done", False)
ss.setdefault("post_done", False)
ss.setdefault("seed", int(np.random.default_rng().integers(1, 99999)))

NAME = {s["key"]: s["name"] for s in P.APPLIANCES.values()}
HOUR_IDX = [f"{h:02d}" for h in range(24)]
FIXED_IDS = [lv["id"] for lv in P.LEVELS]


def hour_labels(tariff):
    """'🟢 03:00' style labels coloured by the tariff of the current level."""
    return {h: f"{P.band(h, tariff)} {h:02d}:00" for h in range(24)}


def active_tariff():
    return P.tariff_for(ss.game["level"]) if ss.game else P.TARIFF

CHECKS = [  # (question, options, index of correct option)
    ("Two appliances almost always run at the same time. What is the safest conclusion?",
     ["Running one causes the other", "They are correlated; that alone does not show that one causes the other", "They are the same appliance"], 1),
    ("In the real REFIT data, roughly what share of whole-house energy came from the nine monitored appliances?",
     ["About 100%", "About one third", "About 5%"], 1),
    ("Which input does the trained model rely on most to forecast next-hour energy?",
     ["Television in the last hour", "Dishwasher in the last hour", "The month"], 1),
]


def pretty(feature):
    if feature.startswith("Appliance"):
        return f"{P.APPLIANCES[int(feature[9])]['name']} (last hour)"
    return {"Previous_Total_Energy_kWh": "Total monitored energy (last hour)", "Hour_sin": "Time of day (sin)",
            "Hour_cos": "Time of day (cos)", "Day_of_Week": "Day of week", "Month": "Month"}.get(feature, feature)


def log_csv(path, header, row):
    new = not os.path.exists(path)
    with open(path, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(header)
        w.writerow(row)


def run_checks(prefix):
    answers = []
    for i, (q, opts, _) in enumerate(CHECKS):
        answers.append(st.radio(q, opts, index=None, key=f"{prefix}_{i}"))
    return answers


def score_checks(answers):
    return sum(1 for a, (_, opts, c) in zip(answers, CHECKS) if a is not None and opts.index(a) == c)


# ------------------------------------------------------------ sidebar
st.sidebar.title("🏠 Appliances Manager")
page = st.sidebar.radio("Go to", ["Play", "Appliance Lab", "Progress", "Model Insights", "How to play"])
st.sidebar.caption(f"Model: {M.model_name()} (one hour ahead)")
st.sidebar.caption(f"Test error: MAE {M.mae():.3f} kWh · RMSE {M.rmse():.3f} kWh per hour")
_lv_now = ss.game["level"] if ss.game else None
st.sidebar.caption(("Tariff today (" + P.TARIFFS[_lv_now.get("tariff", "tou")]["name"] + "): ") if _lv_now else "Default tariff (it changes from level to level): ")
st.sidebar.caption(P.tariff_caption(active_tariff()))
if df is None:
    st.sidebar.info("Optional real hourly data not found in data/. The game works; the 'reality check' and correlation view are off.")


# ------------------------------------------------------------ PLAY
def start_day(level_base, diff, name, idx=None, tier=None):
    """Apply the difficulty to a level and set up the day (budget needs the model, so show a spinner)."""
    level = P.apply_difficulty(level_base, diff)
    with st.spinner("Preparing the day..."):
        base, smart, budget = G.make_budget(level)
    ss.run_id += 1
    ss.game = {"idx": idx, "tier": tier, "diff": diff, "level": level, "base": base, "smart": smart, "budget": budget,
               "name": name or "anon", "result": None, "logged": False, "recorded": False}


def progress_id(level):
    return "random" if level.get("random") else level["id"]


def unlocked_ids(done):
    return [lv["id"] for i, lv in enumerate(P.LEVELS) if i == 0 or P.LEVELS[i - 1]["id"] in done]


def page_play():
    st.title("Smart Home Appliances Manager")
    g = ss.game
    if g is None:
        st.write("Schedule the household's appliances so the day's **electricity bill stays under budget**, the chores get done "
                 "and the supply is never overloaded. A model trained on real household data predicts what your plan will cost.")
        name = st.text_input("Player name (saves your progress and playtest results)", value=ss.player)
        ss.player = name.strip()
        done = PR.passed_levels(ss.player) | ss.passed
        best = {lid: rec for lid, rec in PR.level_rows(ss.player)}
        unlocked = unlocked_ids(done)
        if not ss.pre_done:
            with st.expander("Optional: 3-question pre-check (helps measure what you learn)"):
                pre = run_checks("pre")

        st.subheader("1 · Choose a difficulty")
        diff = st.radio("Difficulty", list(P.DIFFICULTIES), index=1, horizontal=True, label_visibility="collapsed")
        st.caption(P.DIFFICULTIES[diff]["desc"])

        st.subheader("2 · Choose a level")
        rows = []
        for i, lv in enumerate(P.LEVELS):
            rec = best.get(lv["id"])
            status = "✅ passed" if lv["id"] in done else ("▶ open" if lv["id"] in unlocked else "🔒 locked")
            twists = []
            if lv.get("tariff", "tou") != "tou": twists.append(P.TARIFFS[lv["tariff"]]["name"])
            if lv.get("blocked"): twists.append("quiet hours")
            if lv.get("locked_modes"): twists.append("no Eco for some")
            if lv.get("hidden_extra"): twists.append("guests")
            if lv.get("hidden_mult", 1) != 1: twists.append("extreme weather")
            rows.append({"Level": lv["name"], "Tier": P.TIERS[lv["tier"]], "Status": status,
                         "Best": "⭐" * rec["best_stars"] if rec and rec["best_stars"] else "–",
                         "Twists": ", ".join(twists) or "–", "Budget pressure": f"{lv['difficulty'] * 100:.0f}%"})
        st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
        total_stars = sum(rec["best_stars"] for lid, rec in best.items() if lid in FIXED_IDS)
        st.caption(f"Stars collected: {total_stars} / {3 * len(P.LEVELS)} · Pass a level to unlock the next one.")
        lid = st.radio("Level", unlocked, format_func=lambda x: P.LEVEL_BY_ID[x]["name"] + (" ✅" if x in done else ""),
                       label_visibility="collapsed")
        lv_sel = P.LEVEL_BY_ID[lid]
        st.info(lv_sel["tip"] + (("\n\n" + lv_sel["event"]) if lv_sel.get("event") else ""))
        if st.button("Start the day", type="primary"):
            if not ss.pre_done and any(a is not None for a in pre):
                log_csv(C.LEARNING_LOG, ["time", "player", "phase", "score", "answers"],
                        [time.strftime("%Y-%m-%d %H:%M"), ss.player or "anon", "pre", score_checks(pre), "|".join(map(str, pre))])
                ss.pre_done = True
            start_day(lv_sel, diff, ss.player, idx=FIXED_IDS.index(lid)); st.rerun()

        st.subheader("🎲 Random Day (endless mode)")
        n_done = len(done & set(FIXED_IDS))
        if n_done < 3:
            st.caption(f"Pass 3 levels to unlock Random Days (you have passed {n_done}). Each one is a freshly generated, always-solvable day.")
        else:
            c1, c2 = st.columns(2)
            tier = c1.select_slider("Random day difficulty tier", options=[1, 2, 3, 4], value=2, format_func=lambda t: P.TIERS[t])
            seed = int(c2.number_input("Seed (same seed = same day)", min_value=1, max_value=999999, value=ss.seed, step=1))
            if st.button("Start a random day"):
                with st.spinner("Generating a day..."):
                    lvl = G.build_random_level(seed, tier)
                start_day(lvl, diff, ss.player, tier=tier); st.rerun()
        return
    if g["result"] is None:
        play_day(g, g["level"])
    else:
        show_results(g, g["level"])


def play_day(g, level):
    st.subheader(level["name"])
    st.caption(f"Difficulty: **{g['diff']}** · {P.TIERS[level['tier']]} tier · budget pressure {level['difficulty'] * 100:.0f}% · "
               f"supply limit {level['peak_limit']} kWh/h · comfort ≥ {level['comfort_min']}")
    tariff = P.tariff_for(level)
    labels = hour_labels(tariff)
    uses = G.uses_for(level)
    base_sched = G.baseline_schedule(level)
    sched = {}
    if level.get("event"):
        st.warning(level["event"])
    with st.expander("Today's rules, tariff and hidden load", expanded=False):
        for r in P.describe_rules(level):
            st.markdown("• " + r)
        hid = P.hidden_load(level["month"], level["weekday"], level)
        st.line_chart(pd.DataFrame({"Price £/kWh": tariff, "Hidden load kWh": hid}, index=HOUR_IDX), height=180)
        st.caption("Price per kWh (cost) and the hidden load you cannot control (it eats into the supply limit).")
    st.markdown("**Plan the day.** Pick the hours each appliance runs and, where offered, its operating mode. "
                "Hours are coloured by price: 🟢 cheap, 🟡 normal, 🔴 expensive. The fridge always runs.")
    cols = st.columns(2)
    for n, k in enumerate(P.CONTROLLABLE):
        spec = P.APPLIANCES[P.KEY2ID[k]]
        allowed = G.allowed_hours(level, k)
        with cols[n % 2].container(border=True):
            default = [h for h in base_sched[k]["hours"] if h in allowed]
            hrs = st.multiselect(f"{spec['name']} – {uses[k]} use(s)", allowed, default=default,
                                 format_func=lambda h: labels[h], max_selections=uses[k], key=f"h_{k}_{ss.run_id}")
            if k in level.get("blocked", {}):
                st.caption(f"🔇 Cannot run {P.hour_ranges(level['blocked'][k])} today.")
            mode = P.NORMAL
            options = G.mode_options(level, k)
            if len(options) > 1:
                mode = st.selectbox("Operating mode", options, key=f"m_{k}_{ss.run_id}",
                                    help="Lower-energy modes save energy but cost a little comfort.")
                mult, cc = P.APPLIANCES[P.KEY2ID[k]]["modes"][mode]
                if mult < 1:
                    st.caption(f"Saves {round((1 - mult) * 100)}% energy, costs {cc} comfort points.")
            elif len(P.mode_labels(k)) > 1:
                st.caption("🔒 Eco mode is not available today.")
            sched[k] = {"hours": hrs, "mode": mode}

    res = G.evaluate(sched, level)
    st.divider()
    st.markdown("**The household's needs**")
    for nid, ok in res["needs"].items():
        st.write(("✅ " if ok else "❌ ") + P.NEEDS[nid]["label"] + ("" if ok else f" (−{P.NEEDS[nid]['penalty']} comfort)"))
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Predicted bill", f"£{res['cost']:.2f}", f"budget £{g['budget']:.2f}", delta_color="off")
    m2.metric("Energy", f"{res['kwh']:.1f} kWh", f"± £{res['cost_unc']:.2f} cost range", delta_color="off")
    m3.metric("Chores & comfort", f"{res['comfort']:.0f} / 100", f"need ≥ {level['comfort_min']}", delta_color="off")
    m4.metric("Overloaded hours", len(res["overload_hours"]), f"limit {level['peak_limit']} kWh / h", delta_color="off")
    st.progress(min(1.0, res["cost"] / max(g["budget"], 1e-9)))
    if res["overload_hours"]:
        st.error("Overload at " + ", ".join(f"{h:02d}:00" for h in res["overload_hours"]) + ". Spread appliances out.")
    chart = pd.DataFrame({"Your appliances this hour": res["direct"],
                          "Model knock-on from last hour": res["carry"],
                          "Hidden load": res["hidden"]}, index=HOUR_IDX)
    st.bar_chart(chart, height=240)
    st.caption(f"Household energy per hour (overload above {level['peak_limit']} kWh). "
               f"The trained model forecasts the knock-on: **{res['carry_kwh']:.2f} kWh** that it expects to follow your earlier appliance use. "
               f"Only {res['monitored_share'] * 100:.0f}% of the day's energy comes from appliances you control.")
    if st.button("Finish the day", type="primary"):
        g["result"] = {"sched": sched, "res": res}; st.rerun()


def show_results(g, level):
    sched, res = g["result"]["sched"], g["result"]["res"]
    passed, score, stars, ratio = G.score_day(res, g["base"], g["smart"], g["budget"], level)
    if passed:
        ss.passed.add(progress_id(level))
    if not g["recorded"]:
        PR.record(g["name"], progress_id(level), level["name"], score, stars, passed, res["cost"], res["comfort"], g["diff"])
        g["recorded"] = True
    st.title("Day complete " + ("✅" if passed else "❌"))
    st.caption(f"{level['name']} · difficulty **{g['diff']}** (score x{level.get('score_mult', 1.0)}"
               + (f", max {level['star_cap']} stars" if level.get("star_cap", 3) < 3 else "") + ")")
    a, b, c, d = st.columns(4)
    a.metric("Bill", f"£{res['cost']:.2f}", f"budget £{g['budget']:.2f}", delta_color="off")
    b.metric("Chores & comfort", f"{res['comfort']:.0f}", f"need ≥ {level['comfort_min']}", delta_color="off")
    c.metric("Score", score)
    d.metric("Stars", "⭐" * stars or "–")
    if not passed:
        why = []
        if res["cost"] > g["budget"]: why.append("over budget")
        if res["comfort"] < level["comfort_min"]: why.append("too many chores/needs missed or eco compromises")
        if res["overload_hours"]: why.append("supply overloaded")
        st.error("Not passed: " + ", ".join(why))
    if passed and stars < 3:
        tips = []
        if res["comfort"] < 90: tips.append("comfort of 90+ (use fewer Eco modes)")
        if ratio < 0.9: tips.append("saving at least 90% of the possible savings")
        if tips and level.get("star_cap", 3) >= 3:
            st.caption("For more stars: " + " and ".join(tips) + ".")
    st.caption(f"You saved {ratio * 100:.0f}% of the savings that were possible this day (wasteful default £{g['base']['cost']:.2f}).")

    st.subheader("What made the difference?")
    guess = st.radio("Which appliance decision saved the most money?", [NAME[k] for k in P.CONTROLLABLE],
                     index=None, key=f"guess_{ss.run_id}")
    if guess:
        att = G.attribution(sched, level)
        best = max(att, key=lambda k: att[k]["cost"])
        ok = NAME[best] == guess
        (st.success if ok else st.warning)(f"{'Correct' if ok else 'Not quite'}: the biggest saver was **{NAME[best]}** "
                                           f"(£{att[best]['cost']:.2f}).")
        st.bar_chart(pd.DataFrame({"£ saved": {NAME[k]: v["cost"] for k, v in att.items()}}))
        st.caption("Method: put only that appliance back to the wasteful default and ask the model how much more the bill would be. "
                   "Tiny values are within the model's error. Notice how the big machines matter far more than the small ones: "
                   "that is feature importance at work.")
        if not g["logged"]:
            log_csv(C.PLAYTEST_LOG, ["time", "player", "level", "score", "passed", "guess", "guess_correct"],
                    [time.strftime("%Y-%m-%d %H:%M"), g["name"], level["name"], score, passed, guess, ok])
            PR.record_guess(g["name"], ok)
            g["logged"] = True

    st.subheader("The load you cannot see")
    st.write(f"Of the **{res['kwh']:.1f} kWh** in your day, only **{res['monitored_share'] * 100:.0f}%** comes from the appliances the model "
             f"was trained on. About **{res['hidden_kwh']:.1f} kWh** is hidden load (heating, lighting and other devices). "
             f"In the real REFIT data the nine monitored appliances were only about {P.MONITORED_SHARE * 100:.0f}% of household energy, "
             "so the model alone could never predict a whole bill.")

    with st.expander("Reality check: how good is the model on real hours?"):
        if df is None:
            st.info("Real data not loaded. Put REFIT_House2_Hourly_ML_Input_Candidates.csv in the data folder to enable this.")
        else:
            st.dataframe(pd.DataFrame(G.reality_check(df)), hide_index=True)
            st.caption("Forecast vs measured monitored energy on random real hours (some may be training hours). "
                       "Official test scores are on the Model Insights page.")

    if not ss.post_done:
        with st.expander("Optional: post-check (same 3 questions as the pre-check)"):
            post = run_checks("post")
            if st.button("Submit post-check"):
                log_csv(C.LEARNING_LOG, ["time", "player", "phase", "score", "answers"],
                        [time.strftime("%Y-%m-%d %H:%M"), g["name"], "post", score_checks(post), "|".join(map(str, post))])
                ss.post_done = True
                st.success(f"Saved. You scored {score_checks(post)} / {len(CHECKS)}.")

    n1, n2, n3 = st.columns(3)
    if n1.button("Back to levels"):
        ss.game = None; st.rerun()
    if n2.button("Retry this day"):
        ss.run_id += 1
        ss.game = dict(g, result=None, logged=False, recorded=False)
        st.rerun()
    if g["idx"] is not None and passed and g["idx"] + 1 < len(P.LEVELS) and n3.button("Next level"):
        start_day(P.LEVELS[g["idx"] + 1], g["diff"], g["name"], idx=g["idx"] + 1); st.rerun()
    if g["idx"] is None and passed and n3.button("Another random day"):
        ss.seed += 1
        with st.spinner("Generating a day..."):
            lvl = G.build_random_level(ss.seed, g["tier"])
        start_day(lvl, g["diff"], g["name"], tier=g["tier"]); st.rerun()


# ------------------------------------------------------------ APPLIANCE LAB
def page_lab():
    st.title("🔬 Appliance Lab")
    st.write("Run **one use** of one appliance, starting in each hour of the day, and see what it does to the household's energy and bill. "
             "The appliance's own energy is fixed; the model adds what it expects to follow in the next hour.")
    k = st.selectbox("Appliance", P.CONTROLLABLE, format_func=lambda x: NAME[x])
    c1, c2, c3, c4 = st.columns(4)
    month = c1.select_slider("Month", options=list(range(1, 13)), value=5)
    wd = c2.selectbox("Day type", [("Weekday", 2), ("Weekend", 5)], format_func=lambda x: x[0])[1]
    mode = c3.selectbox("Operating mode", P.mode_labels(k))
    tkey = c4.selectbox("Tariff", list(P.TARIFFS), format_func=lambda x: P.TARIFFS[x]["name"])
    hyp = st.radio(f"Your hypothesis: when the {NAME[k].lower()} is started at a different hour, the extra **energy (kWh)** it causes changes…",
                   ["a lot", "only a little", "not at all"], index=None, horizontal=True)
    r = G.marginal_by_hour(k, mode, month, wd, P.TARIFFS[tkey]["array"])
    if hyp:
        l, rr = st.columns(2)
        l.caption("Extra household energy from one use (kWh): own energy + model knock-on")
        l.bar_chart(pd.DataFrame({"Appliance's own energy": r["direct"], "Model knock-on next hour": r["carry"]}, index=HOUR_IDX), height=240)
        rr.caption("Extra bill from one use (£)")
        rr.bar_chart(pd.DataFrame({"£": r["cost"]}, index=HOUR_IDX), height=240)
        spread_e = (r["kwh"].max() - r["kwh"].min()) / max(r["kwh"].mean(), 1e-9)
        spread_c = (r["cost"].max() - r["cost"].min()) / max(r["cost"].mean(), 1e-9)
        truth = "a lot" if spread_e > 0.6 else "only a little" if spread_e > 0.15 else "not at all"
        (st.success if truth == hyp else st.warning)(
            f"Energy changes by about {spread_e * 100:.0f}% across start hours; the **bill** changes by about {spread_c * 100:.0f}%. "
            "Timing matters mostly through the tariff, not through the kWh. The model's knock-on is large for the dishwasher and washing "
            f"machine (up to {r['carry'].max():.2f} kWh here) and close to zero for small appliances.")
        if k == "microwave":
            st.info("Notice the Oven Extractor also switches on with the microwave. In the real data they are almost perfectly "
                    "correlated, but that does not mean the extractor causes microwave use. That is correlation, not causation.")


# ------------------------------------------------------------ PROGRESS
def page_progress():
    st.title("📈 Progress")
    name = st.text_input("Player name", value=ss.player).strip()
    rows = PR.level_rows(name)
    if not rows:
        st.info("No days played yet for this name. Enter the name you play under.")
    else:
        table = pd.DataFrame([{"Level": lv["name"], "Passed": "✅" if lv["passed"] else "–", "Best score": lv["best_score"],
                               "Best stars": "⭐" * lv["best_stars"] or "–", "Attempts": lv["attempts"]}
                              for _, lv in rows])
        st.dataframe(table, hide_index=True)
        done_fixed = [lid for lid, lv in rows if lv["passed"] and lid in FIXED_IDS]
        stars_now = sum(lv["best_stars"] for lid, lv in rows if lid in FIXED_IDS)
        m1, m2 = st.columns(2)
        m1.metric("Levels passed", f"{len(done_fixed)} / {len(P.LEVELS)}")
        m2.metric("Stars", f"{stars_now} / {3 * len(P.LEVELS)}")
        hist = pd.DataFrame(PR.history(name))
        a, b = st.columns(2)
        a.caption("Score over your attempts")
        a.line_chart(hist["score"].reset_index(drop=True))
        b.caption("Bill over your attempts (£)")
        b.line_chart(hist["cost"].reset_index(drop=True))
        gs = PR.guess_stats(name)
        if gs["total"]:
            st.metric("Biggest-saver guesses correct", f"{gs['right']} / {gs['total']}")
            st.caption("If this rises over time, you are learning which appliances really drive energy use.")
    st.subheader("Leaderboard")
    lb = PR.leaderboard()
    st.dataframe(pd.DataFrame(lb), hide_index=True) if lb else st.caption("Nobody has played yet.")


# ------------------------------------------------------------ MODEL INSIGHTS
def page_insights():
    st.title("📊 Model Insights")
    st.write(f"**{M.model_name()}**: forecasts the next hour's total energy of the nine monitored appliances from the previous hour's "
             "appliance readings, the previous total, and time features.")
    st.subheader("How well does it predict? (held-out test set)")
    met = pd.DataFrame(M.metrics()).T[["MAE", "RMSE"]]
    st.dataframe(met.round(3))
    st.bar_chart(met)
    mn, rm = met.loc["Mean Baseline"], met.loc[M.model_name()]
    st.caption(f"The model beats a 'predict the average' baseline by {100 * (1 - rm['MAE'] / mn['MAE']):.0f}% on MAE and "
               f"{100 * (1 - rm['RMSE'] / mn['RMSE']):.0f}% on RMSE: useful, not perfect. Unusually high hours are the hardest to predict.")
    st.subheader("What the model relies on (feature importance)")
    imp = pd.Series({pretty(k): v for k, v in M.importances().items()}).sort_values(ascending=False)
    st.bar_chart(imp)
    st.caption("The dishwasher's previous-hour energy dominates: a dishwasher cycle lasts longer than an hour, so one hour predicts the next. "
               "Small appliances barely register. Importance shows what the model uses, not what causes energy use.")
    st.subheader("What the model cannot do (from its documentation)")
    for line in M.limitations():
        st.write("• " + line)
    st.subheader("What the real REFIT data showed (from the project notebook)")
    st.bar_chart(pd.Series(P.MONTHLY_AVG_KWH, name="kWh / month").sort_values())
    st.caption("Average monthly energy by appliance (13 retained months). The dishwasher is about 40% of monitored energy; "
               "monitored appliances are only about a third of the whole house.")
    st.line_chart(pd.DataFrame({"Average household kWh": P.HOURLY_TOTAL}, index=HOUR_IDX))
    st.caption("Average household energy by hour: sharp morning peak at 08:00, evening plateau 16:00–21:00 (approximate, from the notebook chart).")
    if df is not None:
        st.subheader("Correlation with next-hour monitored energy (real hourly data)")
        corr = df.corr()[C.TARGET].drop(C.TARGET)
        corr.index = [pretty(i) for i in corr.index]
        st.bar_chart(corr.sort_values())
        st.caption("A strong correlation does not mean you can change the outcome by changing that variable.")


# ------------------------------------------------------------ HOW TO PLAY
def page_help():
    st.title("How to play")
    st.markdown("""
**Goal:** run a household day for less than the budget, meet the household's needs, and never overload the supply.

**1. Plan:** for each appliance, pick the hours it runs and (for some) an operating mode. Eco modes save energy but cost a little comfort.
Hours are coloured by tariff: 🟢 cheap overnight, 🟡 normal, 🔴 expensive in the evening peak. Check the ✅/❌ list of the household's needs.

**2. Read the prediction:** each hour's energy = what your appliances use + what the **trained model** expects to follow from the previous hour
+ hidden load you cannot control. Bill, comfort and overloaded hours update live.

**3. Finish the day:** guess which appliance saved the most money, then see the model's answer. Your scores and stars are saved on the Progress page.

**Tiers and difficulty:** 12 levels in four tiers (Beginner, Intermediate, Advanced, Expert); pass a level to unlock the next.
Pick **Relaxed**, **Standard** or **Challenge** before each day: Challenge tightens the budget, the supply limit and the comfort bar for x1.25 score; Relaxed loosens them (x0.8 score, max 2 stars).

**Level twists:** different tariffs (flat, solar-surplus midday dip, evening surge), 🔇 quiet hours when an appliance cannot run, 🔒 days when an Eco mode is unavailable,
extra hidden load from guests or extreme weather, and more household needs (dinner, family TV time, visitors' tea, brunch, music for guests).
Open **Today's rules, tariff and hidden load** during a day to see them all.

**🎲 Random Days:** pass 3 levels to unlock endless, generated days (pick a tier and a seed). Every one is checked to be solvable.

**Appliance Lab:** start one appliance at each hour, form a hypothesis, and see its own energy vs the model's knock-on before the bill is revealed.

**Learning objectives**
1. **Feature importance:** which appliances the model relies on, and which decisions really move the bill.
2. **Correlation vs causation:** appliances used together (microwave and extractor) are not causes of each other; the model's knock-on is a learned pattern, not a guarantee.
3. **Uncertainty and hidden data:** predictions come with an error range, and most household energy is not monitored.
""")


{"Play": page_play, "Appliance Lab": page_lab, "Progress": page_progress, "Model Insights": page_insights, "How to play": page_help}[page]()
