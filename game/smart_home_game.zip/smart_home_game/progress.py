"""Progress tracking saved to progress.json: attempts, best scores, stars, unlocked levels, guess accuracy, leaderboard.

Levels are stored under a stable id (e.g. "mild_weekday"). Old saves that used the numbers 0-3 are migrated on read."""
import json
import os
import time
import config as C
import profiles as P


def _load():
    if os.path.exists(C.PROGRESS_FILE):
        try:
            with open(C.PROGRESS_FILE, encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save(data):
    tmp = C.PROGRESS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)
    os.replace(tmp, C.PROGRESS_FILE)


def _lid(key):
    """Level key -> stable id. Accepts an id, or an old numeric key (0-3) from earlier saves."""
    key = str(key)
    return P.LEGACY_LEVEL_IDS.get(int(key), key) if key.isdigit() else key


def _levels(p):
    """A player's level records keyed by stable id (merging old numeric keys, keeping the better record)."""
    out = {}
    for k, lv in p.get("levels", {}).items():
        lid = _lid(k)
        if lid in out:
            o = out[lid]
            o["attempts"] += lv["attempts"]
            o["best_score"] = max(o["best_score"], lv["best_score"])
            o["best_stars"] = max(o["best_stars"], lv["best_stars"])
            o["passed"] = o["passed"] or lv["passed"]
        else:
            out[lid] = dict(lv)
    return out


def _player(data, name):
    p = data.setdefault(name or "anon", {"levels": {}, "history": [], "guess": {"right": 0, "total": 0}})
    p["levels"] = _levels(p)
    return p


def record(name, level, level_name, score, stars, passed, cost, comfort, difficulty="Standard"):
    """level: stable level id (an old numeric index also works)."""
    data = _load()
    p = _player(data, name)
    lv = p["levels"].setdefault(_lid(level), {"name": level_name, "attempts": 0, "best_score": 0, "best_stars": 0, "passed": False})
    lv["name"] = level_name
    lv["attempts"] += 1
    lv["best_score"] = max(lv["best_score"], int(score))
    lv["best_stars"] = max(lv["best_stars"], int(stars))
    lv["passed"] = bool(lv["passed"] or passed)
    p["history"].append({"time": time.strftime("%Y-%m-%d %H:%M"), "level": level_name, "difficulty": difficulty, "score": int(score),
                         "stars": int(stars), "passed": bool(passed), "cost": round(float(cost), 2), "comfort": round(float(comfort), 1)})
    _save(data)


def record_guess(name, correct):
    data = _load()
    g = _player(data, name)["guess"]
    g["total"] += 1
    g["right"] += int(bool(correct))
    _save(data)


def passed_levels(name):
    """Set of level ids the player has passed."""
    lv = _levels(_load().get(name or "anon", {}))
    return {lid for lid, rec in lv.items() if rec["passed"]}


def level_rows(name):
    """[(level id, record)] in the order the levels appear in the game (random days last)."""
    lv = _levels(_load().get(name or "anon", {}))
    order = {l["id"]: i for i, l in enumerate(P.LEVELS)}
    return sorted(lv.items(), key=lambda kv: order.get(kv[0], 999))


def history(name):
    return _load().get(name or "anon", {}).get("history", [])


def guess_stats(name):
    return _load().get(name or "anon", {}).get("guess", {"right": 0, "total": 0})


def leaderboard():
    rows = []
    for name, p in _load().items():
        lv = _levels(p).values()
        rows.append({"player": name, "stars": sum(l["best_stars"] for l in lv), "levels passed": sum(1 for l in lv if l["passed"]),
                     "best total score": sum(l["best_score"] for l in lv), "days played": len(p.get("history", []))})
    return sorted(rows, key=lambda r: (-r["stars"], -r["best total score"]))
