# Smart Home Appliances Manager (Part B game)

Schedule a household's appliances through a day so the electricity bill stays under budget, the household's needs are met and
the supply is never overloaded. A Random Forest trained on REFIT House 2 hourly data predicts how your decisions change the
household's energy.

## Run
Double-click `run_game.bat` (Windows) or `run_game.command` (Mac), or:
```
pip install -r requirements.txt
streamlit run app.py
```
The model was saved with scikit-learn 1.8.0. A different version still loads but prints a warning, so `requirements.txt` asks for 1.8.0 or newer.
`python test_smoke.py` runs the engine checks (model response, every level solved at every difficulty, special rules, random days, progress file, data loader). It takes about a minute.

## How the trained model is used
`smart_home_energy_model.joblib` forecasts the **next hour's total energy of the nine monitored appliances** from the **previous
hour's** appliance energies, the previous total, hour (sin/cos), day of week and month. `smart_home_model_metadata.json` supplies
its test scores, baselines and documented limitations (shown on the Model Insights page).

Each game hour is built from three parts (`game_engine.py`):

| Part | Source |
|---|---|
| Your appliances this hour | the schedule and operating modes you choose (per-use energies are design assumptions in `profiles.py`) |
| **Model knock-on** | `model(previous-hour state) − model(previous hour with only the fridge on)`: what the trained model expects to follow from your earlier appliance use (e.g. a dishwasher run is usually followed by more use in the next hour) |
| Hidden load | heating, lighting, other devices: **not** predicted by the model (it only covers nine appliances); a notebook-shaped assumption |

So player decisions (which hours, which mode, how many uses) change the model's inputs and therefore its predictions. The day is
assumed to repeat: hour 23 feeds hour 00. The model alone cannot say what *would* happen if an appliance were switched on or off
(see its limitations), so the game uses it as a learned pattern and says so on screen.

## Game design
- **Virtual house:** fridge (always on), dishwasher, washing machine, kettle, microwave (+ linked extractor fan), toaster, TV, Hi-Fi.
- **Decisions:** hours for each use; operating modes (Eco 30°C wash, Eco dishwasher cycle, boil only what you need) that cut energy but cost comfort.
- **Budget:** a per-level tariff and a budget computed from the model between a wasteful default and a cheapest plan, so every level is solvable.
- **Comfort requirements:** chores completed (weighted), eco-mode comfort cost, and household needs (hot breakfast, school uniforms, dinner, family TV time, visitors' tea, brunch, music for guests).
- **Constraints:** per-hour supply limit; overloaded hours fail the day.
- **Scoring:** passes only if bill ≤ budget, comfort ≥ threshold and no overload. Score = savings achieved + comfort − overload penalties (times the difficulty multiplier); up to 3 stars.
- **Feedback:** live bill with error range (model test RMSE), a ✅/❌ needs list, stacked chart of own energy vs model knock-on vs hidden load,
  "which appliance saved the most?" guess with a model-based answer, and a "load you cannot see" reveal.
- **Progress tracking:** `progress.json` stores attempts, best score, stars, passed levels (which unlock the next level), guess accuracy and a leaderboard (Progress page).
- **Appliance Lab:** form a hypothesis, then see one use's own energy vs the model's knock-on for every start hour, on any of the four tariffs.

### 12 levels in four tiers
| # | Level | Tier | What is new |
|---|---|---|---|
| 1 | Mild Weekday | Beginner | Warm-up on the time-of-use tariff |
| 2 | Winter Weekday | Beginner | High hidden load |
| 3 | Flat-Rate Friday | Beginner | Flat tariff: only *how much* you use matters, not *when* |
| 4 | Laundry Weekend | Intermediate | Many chores, tighter supply limit |
| 5 | Solar Saturday | Intermediate | Cheapest power is at midday, not at night |
| 6 | Quiet Neighbours | Intermediate | 🔇 Quiet hours: dishwasher and washer lose their cheap slots |
| 7 | Winter Party | Advanced | High hidden load, many chores, tight limit |
| 8 | Surge Thursday | Advanced | Surge tariff (£0.60 in the evening) and dinner + TV needs inside it |
| 9 | Heavy Laundry Week | Advanced | 🔒 Washer has no Eco mode; three washes |
| 10 | Dinner Guests | Expert | Guests add hidden load; dishwasher blocked during dinner; four needs |
| 11 | Cold-Snap Watch | Expert | Hidden load x1.25, locked dishwasher Eco, surge tariff |
| 12 | Grand Finale | Expert | Everything at once |

### Difficulty settings (chosen before each day)
| Setting | Budget | Supply limit | Comfort bar | Score | Stars |
|---|---|---|---|---|---|
| Relaxed | looser (−15% of the possible savings) | +0.25 kWh/h | −5 | x0.8 | max 2 |
| Standard | as designed | as designed | as designed | x1.0 | max 3 |
| Challenge | tighter (+10%) | −0.10 kWh/h | +4 | x1.25 | max 3 |

### Random Days (unlocked after passing 3 levels)
Endless generated days: random month, weekday, tariff, needs and twists (quiet hours, locked Eco, guests, extreme weather) for a chosen tier and seed.
The supply limit is set from the cheapest plan so every random day is solvable; the same seed always gives the same day.

### Adding or changing a level
Add a dict to `_LEVELS` in `profiles.py`. Optional keys: `tariff` (`tou`, `flat`, `solar`, `surge`), `blocked` (`{appliance: [hours]}`), `locked_modes` (`[appliances]`),
`hidden_mult`, `hidden_extra` (`{hour: kWh}`), `event` (text), `uses`, `needs`. Run `python test_smoke.py`: it checks that the level is solvable at all three difficulties.
Keep `peak_limit` at least about 0.25 kWh/h above the cheapest plan's busiest hour so Challenge stays solvable. New tariffs go in `TARIFFS`, new needs in `NEEDS`.

## Learning objectives
1. **Feature importance:** the dishwasher dominates the model and the savings; small appliances barely register.
2. **Correlation vs causation:** microwave and extractor move together without one causing the other; the model's knock-on is a learned pattern, not a guarantee.
3. **Uncertainty and hidden data:** forecasts carry an error range, and only about a third of household energy is monitored.

## Evidence of learning (fill in after playtesting)
Optional 3-question pre/post check is saved to `learning_check_log.csv`; every finished day and guess goes to `playtest_log.csv`.

| Player | Pre-check (/3) | Post-check (/3) | Levels passed | Guess accuracy | Feedback / what surprised them |
|---|---|---|---|---|---|
| | | | | | |

## Assumptions to review
- Per-use energies, allowed hours, tariffs, modes, needs, level twists, difficulty settings and levels are design assumptions (`profiles.py`, marked ASSUMED).
- Hidden load and seasonality come from the notebook's charts, not from the model (the model barely uses `Month`).
- Inputs assume `Hour_sin/Hour_cos` were computed from the hour being predicted and `Day_of_Week` is 0 = Monday. Confirm with whoever trained the model.
- Optional: copy `REFIT_House2_Hourly_ML_Input_Candidates.csv` into `data/` to enable the reality check and correlation view.

## Files
`app.py` UI · `game_engine.py` rules and model integration · `model_interface.py` only model access · `profiles.py` appliances, tariff, needs, levels ·
`progress.py` progress tracking (stable level ids; old 4-level saves are migrated automatically) · `data_loader.py` optional real data · `config.py` · `test_smoke.py`
