#!/bin/bash
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null; then echo "Install Python from python.org first."; read -p "Press Enter"; exit 1; fi
python3 -c "import streamlit, sklearn, pandas, joblib" 2>/dev/null || python3 -m pip install -r requirements.txt
python3 -m streamlit run app.py
