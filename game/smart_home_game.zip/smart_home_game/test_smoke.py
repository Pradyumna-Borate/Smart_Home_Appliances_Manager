"""Quick checks: python test_smoke.py   (takes about a minute: it solves every level at every difficulty)"""
import os, tempfile, json
import numpy as np
import pandas as pd
import config as C, profiles as P, data_loader as D, game_engine as G, model_interface as M, progress as PR

print("model:", M.model_name(), "| features:", len(M.feature_names()), "| test RMSE:", round(M.rmse(), 3), "MAE:", round(M.mae(), 3))
assert M.feature_names()[:9] == [f"Appliance{i}_Energy_kWh_lag1" for i in range(1, 10)]

# the model must respond to the player's decisions
idle = G.appliance_matrix({k: {"hours": [], "mode": P.NORMAL} for k in P.CONTROLLABLE})
assert G.knock_on(idle, 2, 5).max() == 0, "no appliance use must mean no knock-on"
dish = {k: {"hours": [], "mode": P.NORMAL} for k in P.CONTROLLABLE}; dish["dishwasher"]["hours"] = [22]
k = G.knock_on(G.appliance_matrix(dish), 2, 5)
assert k[23] > 0.1 and k.sum() == k[23], "dishwasher in hour 22 should raise the forecast for hour 23 only"
print("dishwasher at 22:00 -> model knock-on at 23:00 =", round(float(k[23]), 3), "kWh")

# ---- level data
assert len(P.LEVELS) >= 12 and len({l["id"] for l in P.LEVELS}) == len(P.LEVELS)
assert [l["tier"] for l in P.LEVELS] == sorted(l["tier"] for l in P.LEVELS), "levels must get harder tier by tier"
for t in P.TARIFFS.values():
    assert len(t["array"]) == 24 and (t["array"] > 0).all()
for lv in P.LEVELS:
    uses = G.uses_for(lv)
    for kk in P.CONTROLLABLE:
        assert uses[kk] <= len(G.allowed_hours(lv, kk)), f"{lv['name']}: more uses than free hours for {kk}"
    for nid in lv["needs"]:
        assert any(G.allowed_hours(lv, a) and set(P.NEEDS[nid]["hours"]) & set(G.allowed_hours(lv, a)) for a in P.NEEDS[nid]["appliances"]), \
            f"{lv['name']}: need {nid} cannot be met"

# ---- every level must be solvable at every difficulty, and the rules must really apply
for lv0 in P.LEVELS:
    for dname in P.DIFFICULTIES:
        lv = P.apply_difficulty(lv0, dname)
        base, smart, budget = G.make_budget(lv)
        assert smart["cost"] < budget < base["cost"], f"{lv['name']}/{dname}: budget must lie between smart and baseline"
        assert not smart["overload_hours"], f"{lv['name']}/{dname}: smart schedule must not overload"
        assert smart["comfort"] >= lv["comfort_min"], f"{lv['name']}/{dname}: smart schedule must satisfy comfort"
        assert all(smart["needs"].values()), f"{lv['name']}/{dname}: smart schedule must meet every need"
        sm = G.smart_schedule(lv)
        for kk in P.CONTROLLABLE:
            assert set(sm[kk]["hours"]) <= set(G.allowed_hours(lv, kk)), "smart schedule used a blocked hour"
            assert sm[kk]["mode"] in G.mode_options(lv, kk), "smart schedule used a locked mode"
            assert len(set(sm[kk]["hours"])) == G.uses_for(lv)[kk]
        if dname == "Standard":
            print(f"{lv['name']:32s} [{P.TIERS[lv['tier']]:12s}] baseline £{base['cost']:.2f} (overload {base['overload_hours']}), "
                  f"smart £{smart['cost']:.2f}, budget £{budget:.2f}, limit {lv['peak_limit']}")
print("all", len(P.LEVELS) * len(P.DIFFICULTIES), "level/difficulty combinations are solvable")

# ---- difficulty ordering: Challenge is tighter than Standard, which is tighter than Relaxed
lv0 = P.LEVELS[3]
r, s_, c = (P.apply_difficulty(lv0, d) for d in ("Relaxed", "Standard", "Challenge"))
assert r["difficulty"] < s_["difficulty"] < c["difficulty"] and r["peak_limit"] > s_["peak_limit"] > c["peak_limit"]
assert r["comfort_min"] < s_["comfort_min"] < c["comfort_min"]
assert P.apply_difficulty(lv0, "Standard") == {**lv0, "score_mult": 1.0, "star_cap": 3, "mode_name": "Standard"}
bs = [G.make_budget(x)[2] for x in (r, s_, c)]
assert bs[0] > bs[1] > bs[2], "tighter difficulty means a lower budget"
# score multiplier and star cap
base, smart, budget = G.make_budget(s_)
res = G.evaluate(G.smart_schedule(s_), s_)
_, sc_std, st_std, _ = G.score_day(res, base, smart, budget, s_)
_, sc_rel, st_rel, _ = G.score_day(res, base, smart, budget, r)
_, sc_cha, st_cha, _ = G.score_day(res, base, smart, budget, c)
assert sc_rel < sc_std < sc_cha and st_rel <= 2 and st_std == 3
print("scores (Relaxed/Standard/Challenge) for the same plan:", sc_rel, sc_std, sc_cha)

# ---- special rules
solar, flat = P.TARIFFS["solar"]["array"], P.TARIFFS["flat"]["array"]
assert int(np.argmin(solar)) in range(10, 16) and P.band(12, solar) == "🟢" and P.band(18, solar) == "🔴"
assert all(P.band(h, flat) == "🟡" for h in range(24))
guest = P.LEVEL_BY_ID["dinner_guests"]
assert P.hidden_load(12, 5, guest)[19] > P.hidden_load(12, 5)[19] + 0.2, "guests must add hidden load"
cold = P.LEVEL_BY_ID["cold_snap"]
assert abs(P.hidden_load(1, 1, cold)[8] / P.hidden_load(1, 1)[8] - 1.25) < 1e-9
assert G.mode_options(P.LEVEL_BY_ID["heavy_laundry"], "washer") == [P.NORMAL]
assert len(G.mode_options(P.LEVEL_BY_ID["heavy_laundry"], "dishwasher")) == 2
assert 3 not in G.allowed_hours(P.LEVEL_BY_ID["quiet_neighbours"], "dishwasher") and 9 not in G.allowed_hours(P.LEVEL_BY_ID["quiet_neighbours"], "washer")
assert P.hour_ranges([23, 0, 1, 2, 3, 4, 5, 6]) == "23:00–06:59"
# the same plan costs different amounts on different tariffs
plan = G.baseline_schedule(P.LEVELS[0])
costs = {t: G.evaluate(plan, dict(P.LEVELS[0], tariff=t))["cost"] for t in P.TARIFFS}
assert len({round(v, 3) for v in costs.values()}) == len(costs), costs
print("same plan on each tariff:", {t: round(v, 2) for t, v in costs.items()})

# ---- random days are reproducible and solvable
a1, a2 = G.build_random_level(5, 3), G.build_random_level(5, 3)
assert json.dumps(a1, sort_keys=True, default=str) == json.dumps(a2, sort_keys=True, default=str)
for tier in (1, 2, 3, 4):
    for dname in ("Relaxed", "Challenge"):
        assert G.check_solvable(P.apply_difficulty(G.build_random_level(11 + tier, tier), dname))
print("random days OK")

lv = P.LEVELS[0]
m = G.marginal_by_hour("dishwasher", P.NORMAL, 5, 2)
assert m["carry"].max() > m["carry"].min() >= 0
m2 = G.marginal_by_hour("dishwasher", P.NORMAL, 5, 2, P.TARIFFS["surge"]["array"])
assert not np.allclose(m["cost"], m2["cost"])
print("attribution:", {k: round(v["cost"], 3) for k, v in G.attribution(G.smart_schedule(lv), lv).items()})

# ---- progress tracking (temp file), including migration of old numeric level keys
C.PROGRESS_FILE = os.path.join(tempfile.mkdtemp(), "p.json")
PR.record("tester", "mild_weekday", "L1", 700, 2, True, 2.3, 92); PR.record("tester", "mild_weekday", "L1", 500, 0, False, 2.9, 85, "Challenge")
PR.record_guess("tester", True)
assert PR.passed_levels("tester") == {"mild_weekday"} and PR.level_rows("tester")[0][1]["attempts"] == 2
assert PR.leaderboard()[0]["stars"] == 2 and PR.history("tester")[-1]["difficulty"] == "Challenge"
with open(C.PROGRESS_FILE, "w") as f:      # a save file from the old 4-level game
    json.dump({"old": {"levels": {"0": {"name": "Level 1", "attempts": 3, "best_score": 800, "best_stars": 3, "passed": True},
                                  "3": {"name": "Level 4", "attempts": 1, "best_score": 100, "best_stars": 0, "passed": False}},
                       "history": [], "guess": {"right": 1, "total": 2}}}, f)
assert PR.passed_levels("old") == {"mild_weekday"} and [r[0] for r in PR.level_rows("old")] == ["mild_weekday", "winter_party"]
PR.record("old", "winter_party", "Level 7", 900, 2, True, 3.0, 90)
assert PR.passed_levels("old") == {"mild_weekday", "winter_party"}
print("progress OK")

# ---- optional real-data loader (tiny fake CSV in a temp dir, only to test the code path)
d = tempfile.mkdtemp(); C.INPUT_CSV = os.path.join(d, "x.csv")
idx = pd.date_range("2014-03-03", periods=200, freq="h")
rng = np.random.default_rng(0)
pd.DataFrame({c: rng.random(200) * 0.1 for c in C.ENERGY_COLS}, index=idx).rename_axis("Hour").to_csv(C.INPUT_CSV)
df = D.load_hourly()
assert list(df.columns) == M.feature_names() + [C.TARGET] and len(df) == 199
print("reality check rows:", len(G.reality_check(df, n=5)))
print("OK")
